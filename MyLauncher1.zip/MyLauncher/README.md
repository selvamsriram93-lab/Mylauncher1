# My Launcher

Custom Android launcher (Kotlin + Jetpack Compose).

## Build the APK on GitHub
1. Push this folder to a new GitHub repository.
2. Open Actions > Build APK > Run workflow (it also runs on every push).
3. When it finishes, download the `app-debug` artifact, unzip it and install the APK.
4. Set it as home: Settings > Apps > Default apps > Home app.

Long-press an app in the drawer to open its App info (uninstall, etc.).
